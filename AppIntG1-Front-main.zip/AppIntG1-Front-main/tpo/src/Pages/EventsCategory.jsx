import React from 'react'

const EventsCategory = () => {
    return ( 
        <div>
            
        </div>
     );
}
 
export default EventsCategory;
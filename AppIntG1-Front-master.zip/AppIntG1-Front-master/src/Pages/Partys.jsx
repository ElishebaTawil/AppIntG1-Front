import React from 'react'

const Partys = () => {
    return ( 
        <div>
            
        </div>
     );
}
 
export default Partys;
import karolg from '../Assets/karolg.jpg';
import mamamia from '../Assets/mamamia.png';
import milos from '../Assets/milo_s.png';
import minecrack from '../Assets/minecrack.png';
let newCollections =[
    {
        id: 1,
        name: "Karol.G",
        image: karolg,
        new_price: 30,
        old_price: 44
    },
    {
        id: 2,
        name: "MikeCrack",
        image: minecrack,
        new_price: 387,
        old_price: 300
    },
    {
        id: 3,
        name: "Milo.S",
        image: milos,
        new_price: 69.99,
        old_price: 99.99
    },
    {
        id: 4,
        name: "Mamamia",
        image: mamamia,
        new_price: 10,
        old_price: 20
    }
]
export default newCollections;